#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "pilha.h"

int valpre(char *e) {
    Pilha P = pilha(256);
    int len = strlen(e);
    
    for (int i = len - 1; i >= 0; i--) {
        char c = e[i];
        
        if (isdigit(c)) {
            empilha(c - '0', P);
        } 
        else if (strchr("+-*/", c)) {
            int y = desempilha(P); 
            int x = desempilha(P);

            switch (c) {
                case '+':
                    empilha(x + y, P);
                    break;
                case '-':
                    empilha(x - y, P);
                    break;
                case '*':
                    empilha(x * y, P);
                    break;
                case '/':
                    if (y != 0) {
                        empilha(x / y, P);
                    } else {
                        fprintf(stderr, "Erro: Divisão por zero.\n");
                        destroip(&P);
                        return 0;
                    }
                    break;
            }
        }
        else if (c == ' ') { 
            continue;
        } 
    }

    if (vaziap(P)) { 
        return 0;
    }
    
    int z = desempilha(P);
    
    if (!vaziap(P)) {
        destroip(&P);
        return 0;
    }
    
    destroip(&P);
    return z;
}

int main(void) {
    char e[513];
    int resultado;

    printf("Prefixa? ");
    gets(e); 

    resultado = valpre(e);

    printf("Resultado: %d\n", resultado);

    return 0;
}