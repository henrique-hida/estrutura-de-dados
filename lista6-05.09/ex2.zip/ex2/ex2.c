#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilha.h"
#include "fila.h"


int concha(char *c) {
    Pilha P = pilha(strlen(c)); 
    int resultado = 1;

    if (!P) return 0;

    for (int i = 0; c[i] != '\0'; i++) {
        
        if (vaziap(P)) {
            empilha((Itemp)c[i], P); 
        } else {
            char topo_char = (char)topo(P);

            if (c[i] == topo_char) {
                desempilha(P); 
            } else {
                resultado = 0;
                break;
            }
        }
    }

    if (!vaziap(P)) {
        resultado = 0;
    }

    destroip(&P);
    return resultado;
}


void filtra(Fila F) {
    int total_conchas = 0;
    Itemf item_fila; 
    char *cadeia_atual;

    printf("--- Cadeias 'Concha' Encontradas ---\n");

    while (!vaziaf(F)) {
        
        item_fila = desenfileira(F);
        
        // Causa o warning, mas é a sua tipagem atual: int -> char*
        cadeia_atual = (char*)item_fila; 

        if (concha(cadeia_atual)) {
            printf("%s\n", cadeia_atual);
            total_conchas++;
        }
    }

    printf("------------------------------------\n");
    printf("Total de cadeias que são 'conchas': %d\n", total_conchas);
}

// ... FUNÇÕES concha() e filtra() VÃO AQUI EM CIMA ...

int main() {
    const int TAMANHO_FILA = 5;
    Fila F_teste = fila(TAMANHO_FILA);

    char buffer[256]; 
    char *cadeia_copia;

    printf("--- Teste de Validação de 'Concha' ---\n");
    printf("Digite a cadeia (Ex: AAABAAABBAABAAAA ou BBBAAAAAABA):\n");
    
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        destroif(&F_teste);
        return 1;
    }
    buffer[strcspn(buffer, "\n")] = 0; 
    
    cadeia_copia = (char*)malloc(strlen(buffer) + 1);
    if (cadeia_copia == NULL) {
        destroif(&F_teste);
        return 1;
    }
    strcpy(cadeia_copia, buffer);

    enfileira((Itemf)cadeia_copia, F_teste);

    printf("\nProcessando a fila...\n");
    filtra(F_teste);
    
    free(cadeia_copia); 
    destroif(&F_teste);

    return 0;
}